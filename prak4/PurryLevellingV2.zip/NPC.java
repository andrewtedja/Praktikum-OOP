public class NPC extends Unit implements Interactable {
    private String dialogue;

    public NPC() {
        this.name = "NPC1";
        this.health = 100;
        this.dialogue = "Hello there!";
    }

    public NPC(String name, int health, String dialogue) {
        this.name = name;
        this.health = health;
        this.dialogue = dialogue;
    }

    public String getDialogue() {
        return this.dialogue;
    }

    public void setDialogue(String d) {
        this.dialogue = d;
    }

    public void interact() {
        System.out.println(this.dialogue);
    }

    @Override
    public String toString() {
        return (this.name + " [Health: " + this.health + ", Dialogue: " + this.dialogue + "]");
    }
}