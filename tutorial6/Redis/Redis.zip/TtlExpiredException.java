public class TtlExpiredException extends RuntimeException {

    public TtlExpiredException(String msg) {
        super(msg);
    }   
}